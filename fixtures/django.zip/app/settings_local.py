DEBUG = True

DATABASES = {
	'default': {
		'ENGINE': 'django.db.backends.%(dbengine)s',
		'NAME': '%(prefix)s',
		'USER': '%(prefix)s',
		'PASSWORD': '%(password)s',
		'HOST': '',
		'PORT': ''
	}
}

ALLOWED_HOSTS = []